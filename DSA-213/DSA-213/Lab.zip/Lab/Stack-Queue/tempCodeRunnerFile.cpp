while(!S.empty()){
	// 	cout<<S.top()<<endl;
	// 	S.pop();
	// }